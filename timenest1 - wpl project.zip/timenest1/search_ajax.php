<?php
session_start();
include 'includes/db.php';

$q = $_GET['q'] ?? '';
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? '';

// Build SQL
$sql = "SELECT * FROM products WHERE 1";
$params = [];
$types = "";

// Search filter
if ($q !== '') {
    $sql .= " AND name LIKE ?";
    $params[] = "%$q%";
    $types .= "s";
}

// Category filter (skip if 'All' or empty)
if ($category !== '' && strtolower($category) !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}

// Sorting
switch($sort){
    case 'price_asc': $sql .= " ORDER BY price ASC"; break;
    case 'price_desc': $sql .= " ORDER BY price DESC"; break;
    case 'name_asc': $sql .= " ORDER BY name ASC"; break;
    case 'name_desc': $sql .= " ORDER BY name DESC"; break;
    default: $sql .= " ORDER BY id DESC"; break;
}

// Prepare and execute
$stmt = $conn->prepare($sql);
if(!empty($params)){
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// No results
if($result->num_rows === 0){
    echo '<p style="text-align:center; color:#aaa;">No products found.</p>';
    exit;
}

// Display results
while($row = $result->fetch_assoc()): ?>
    <div class="product">
        <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
        <div class="product-overlay">
            <a href="product.php?id=<?= $row['id'] ?>">View Details</a>
        </div>
        <h4><?= htmlspecialchars($row['name']) ?></h4>
        <p>$<?= htmlspecialchars($row['price']) ?></p>
        <form action="add_to_cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
            <button type="submit">Add to Cart</button>
        </form>
    </div>
<?php endwhile; ?>
