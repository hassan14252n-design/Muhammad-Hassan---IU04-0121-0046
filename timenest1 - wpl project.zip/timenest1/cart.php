<?php
session_start();
include 'includes/db.php';

$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart – TimeNest</title>
    <link rel="stylesheet" href="style.css">

    <style>
        .cart-page {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }

        .cart-title {
            text-align: center;
            color: #c2b280;
            margin-bottom: 30px;
        }

        .cart-item {
            display: grid;
            grid-template-columns: 100px 1fr 120px 140px 80px;
            gap: 20px;
            align-items: center;
            background: #1a1a1a;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .cart-item img {
            width: 100px;
            height: 120px;
            object-fit: cover;
            border-radius: 8px;
        }

        .cart-item h4 {
            margin: 0;
            color: #f5f5dc;
        }

        .cart-price {
            color: #c2b280;
            font-weight: bold;
        }

        .cart-qty input {
            width: 60px;
            padding: 6px;
            border-radius: 6px;
            border: 1px solid #333;
            background: #121212;
            color: #f5f5dc;
            text-align: center;
        }

        .remove-btn {
            background: #ff6a3d;
            border: none;
            color: white;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
        }

        .cart-total {
            text-align: right;
            margin-top: 30px;
            font-size: 20px;
            color: #f5f5dc;
        }

        .checkout-btn {
            display: inline-block;
            margin-top: 15px;
            background: #c2b280;
            color: #121212;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
        }

        .empty-cart {
            text-align: center;
            color: #aaa;
            margin-top: 60px;
        }

        .continue-btn {
            display: inline-block;
            margin-top: 15px;
            color: #c2b280;
            text-decoration: none;
            font-weight: bold;
        }

        .continue-btn:hover {
            text-decoration: underline;
        }

        .cart-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="cart-page">
    <h1 class="cart-title">🛒 Your Cart</h1>

    <?php if (empty($cart)): ?>
        <p class="empty-cart">Your cart is empty. Go buy something nice 😌</p>
        <div style="text-align:center;">
            <a href="index.php" class="continue-btn">← Continue Shopping</a>
        </div>
    <?php else: ?>

        <?php foreach ($cart as $item): 
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
        ?>
            <div class="cart-item">
                <img src="uploads/<?= htmlspecialchars($item['image']) ?>">

                <h4><?= htmlspecialchars($item['name']) ?></h4>

                <div class="cart-price">Rs <?= number_format($item['price'], 2) ?></div>

                <!-- UPDATE QTY -->
                <form action="update_cart.php" method="POST" class="cart-qty">
                    <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" min="1" value="<?= $item['quantity'] ?>" onchange="this.form.submit()">
                </form>

                <!-- REMOVE -->
                <form action="remove_from_cart.php" method="POST">
                    <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                    <button class="remove-btn">✕</button>
                </form>
            </div>
        <?php endforeach; ?>

        <div class="cart-total">
            <strong>Total:</strong> Rs <?= number_format($total, 2) ?>
        </div>

        <div class="cart-actions">
            <a href="index.php" class="continue-btn">← Continue Shopping</a>

            <!-- CHECKOUT -->
            <a href="checkout.php" class="checkout-btn">
                Proceed to Checkout
            </a>
        </div>

    <?php endif; ?>
</div>

</body>
</html>
