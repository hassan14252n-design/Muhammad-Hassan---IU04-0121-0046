<?php
session_start();
include 'includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Email already exists.";
    } else {
        $insert = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $insert->bind_param("sss", $fullname, $email, $password);

        if ($insert->execute()) {
            $_SESSION['user'] = [
                'id' => $insert->insert_id,
                'name' => $fullname
            ];
            header("Location: index.php");
            exit();
        } else {
            $error = "Something went wrong. Try again.";
        }
        $insert->close();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up - TimeNest</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="form-page">

<div class="form-box">
    <h2>Create Account</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Sign Up</button>
    </form>

    <p>Already have an account? <a href="login.php">Login</a></p>
</div>

</body>
</html>
