-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2025 at 02:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timenest1`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `created_at`, `full_name`, `email`, `phone`, `address`, `city`, `payment_method`, `is_active`) VALUES
(9, 3, 4500.00, 'Completed', '2025-12-28 19:08:13', 'eman raza', 'eman.raza@timenest.com', '0323567789', 'gulshan iqbal block 10-a', 'Karachi', 'Cash on Delivery', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `price`) VALUES
(9, 9, 35, NULL, 1, 4500.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `category` varchar(50) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `quantity`, `category`, `image2`, `image3`, `is_active`) VALUES
(1, 'Classic Leather Watch', 'Leather strap watch with stainless steel casing and quartz movement.', 42000.00, 'watch1.jpg', 20, 'watches', 'watch1_2.jpg', 'watch1_3.jpg', 1),
(2, 'Minimal Black Dial Watch', 'Minimal black dial watch designed for modern daily wear.', 48000.00, 'watch2.jpg', 20, 'watches', 'watch2_2.jpg', 'watch2_3.jpg', 1),
(3, 'Silver Chronograph Watch', 'Premium chronograph watch with polished silver finish.', 62000.00, 'watch3.jpg', 15, 'watches', 'watch3_2.jpg', 'watch3_3.jpg', 1),
(4, 'Luxury Gold Watch', 'Gold-tone luxury watch for elegant occasions.', 85000.00, 'watch4.jpg', 10, 'watches', 'watch4_2.jpg', 'watch4_3.jpg', 1),
(5, 'Sport Chrono Watch', 'Sport watch with water resistance and bold design.', 54000.00, 'watch5.jpg', 18, 'watches', 'watch5_2.jpg', 'watch5_3.jpg', 1),
(6, 'Brown Strap Classic Watch', 'Classic brown leather strap analog watch.', 45000.00, 'watch6.jpg', 20, 'watches', 'watch6_2.jpg', 'watch6_3.jpg', 1),
(7, 'Midnight Black Watch', 'All-black watch with matte modern finish.', 51000.00, 'watch7.jpg', 15, 'watches', 'watch7_2.jpg', 'watch7_3.jpg', 1),
(8, 'Steel Mesh Watch', 'Stainless steel mesh strap watch with refined style.', 57000.00, 'watch8.jpg', 12, 'watches', 'watch8_2.jpg', 'watch8_3.jpg', 1),
(9, 'Modern Square Watch', 'Square dial watch for bold contemporary looks.', 60000.00, 'watch9.jpg', 14, 'watches', 'watch9_2.jpg', 'watch9_3.jpg', 1),
(10, 'Vintage Roman Watch', 'Vintage-style watch with Roman numeral dial.', 54000.00, 'watch10.jpg', 16, 'watches', 'watch10_2.jpg', 'watch10_3.jpg', 1),
(11, 'Genuine Leather Wallet', 'Handcrafted genuine leather wallet with premium stitching.', 1400.00, 'wallet1.jpg', 30, 'wallets', 'wallet1_2.jpg', 'wallet1_3.jpg', 1),
(12, 'RFID Blocking Wallet', 'RFID-protected wallet to prevent digital theft.', 1600.00, 'wallet2.jpg', 25, 'wallets', 'wallet2_2.jpg', 'wallet2_3.jpg', 1),
(13, 'Slim Card Holder', 'Ultra-slim card holder for minimal carry.', 1100.00, 'wallet3.jpg', 35, 'wallets', 'wallet3_2.jpg', 'wallet3_3.jpg', 1),
(14, 'Brown Fold Wallet', 'Classic brown bi-fold wallet.', 1500.00, 'wallet4.jpg', 28, 'wallets', 'wallet4_2.jpg', 'wallet4_3.jpg', 1),
(15, 'Black Executive Wallet', 'Executive leather wallet with sleek finish.', 1800.00, 'wallet5.jpg', 22, 'wallets', 'wallet5_2.jpg', 'wallet5_3.jpg', 1),
(16, 'Minimal Leather Wallet', 'Minimalist leather wallet for everyday use.', 1200.00, 'wallet6.jpg', 30, 'wallets', 'wallet6_2.jpg', 'wallet6_3.jpg', 1),
(17, 'Vintage Leather Wallet', 'Vintage leather wallet with rustic appeal.', 1500.00, 'wallet7.jpg', 20, 'wallets', 'wallet7_2.jpg', 'wallet7_3.jpg', 1),
(18, 'Compact Zip Wallet', 'Compact wallet with secure zip compartments.', 1500.00, 'wallet8.jpg', 25, 'wallets', 'wallet8_2.jpg', 'wallet8_3.jpg', 1),
(19, 'Luxury Stitch Wallet', 'Luxury wallet with fine contrast stitching.', 2500.00, 'wallet9.jpg', 18, 'wallets', 'wallet9_2.jpg', 'wallet9_3.jpg', 1),
(20, 'Everyday Classic Wallet', 'Durable wallet designed for daily wear.', 4000.00, 'wallet10.jpg', 32, 'wallets', 'wallet10_2.jpg', 'wallet10_3.jpg', 1),
(21, 'Leather Office Bag', 'Premium leather office bag with spacious compartments.', 5000.00, 'bag1.jpg', 12, 'bags', 'bag1_2.jpg', 'bag1_3.jpg', 1),
(22, 'Casual Shoulder Bag', 'Lightweight shoulder bag for daily use.', 3000.00, 'bag2.jpg', 15, 'bags', 'bag2_2.jpg', 'bag2_3.jpg', 1),
(23, 'Travel Duffel Bag', 'Large duffel bag ideal for travel.', 6000.00, 'bag3.jpg', 10, 'bags', 'bag3_2.jpg', 'bag3_3.jpg', 1),
(24, 'Urban Backpack', 'Modern backpack with durable construction.', 5000.00, 'bag4.jpg', 18, 'bags', 'bag4_2.jpg', 'bag4_3.jpg', 1),
(25, 'Classic Messenger Bag', 'Professional messenger bag with timeless style.', 4000.00, 'bag5.jpg', 14, 'bags', 'bag5_2.jpg', 'bag5_3.jpg', 1),
(26, 'Leather Laptop Bag', 'Leather laptop bag with padded protection.', 6000.00, 'bag6.jpg', 12, 'bags', 'bag6_2.jpg', 'bag6_3.jpg', 1),
(27, 'Minimal Tote Bag', 'Minimalist tote bag for everyday essentials.', 30000.00, 'bag7.jpg', 20, 'bags', 'bag7_2.jpg', 'bag7_3.jpg', 1),
(28, 'Premium Travel Bag', 'High-end travel bag with reinforced handles.', 2000.00, 'bag8.jpg', 8, 'bags', 'bag8_2.jpg', 'bag8_3.jpg', 1),
(29, 'Canvas Casual Bag', 'Casual canvas bag for relaxed use.', 9000.00, 'bag9.jpg', 22, 'bags', 'bag9_2.jpg', 'bag9_3.jpg', 1),
(30, 'Executive Briefcase', 'Executive briefcase for corporate professionals.', 12000.00, 'bag10.jpg', 6, 'bags', 'bag10_2.jpg', 'bag10_3.jpg', 1),
(31, 'Leather Wrap Bracelet', 'Stylish leather wrap bracelet with metal clasp.', 1500.00, 'bracelet1.jpg', 40, 'bracelets', 'bracelet1_2.jpg', 'bracelet1_3.jpg', 1),
(32, 'Minimal Steel Bracelet', 'Minimal stainless steel bracelet.', 1500.00, 'bracelet2.jpg', 35, 'bracelets', 'bracelet2_2.jpg', 'bracelet2_3.jpg', 1),
(33, 'Beaded Stone Bracelet', 'Natural stone beaded bracelet.', 1000.00, 'bracelet3.jpg', 38, 'bracelets', 'bracelet3_2.jpg', 'bracelet3_3.jpg', 1),
(34, 'Black Leather Bracelet', 'Modern black leather bracelet.', 5000.00, 'bracelet4.jpg', 42, 'bracelets', 'bracelet4_2.jpg', 'bracelet4_3.jpg', 1),
(35, 'Silver Chain Bracelet', 'Elegant silver chain bracelet.', 4500.00, 'bracelet5.jpg', 30, 'bracelets', 'bracelet5_2.jpg', 'bracelet5_3.jpg', 1),
(36, 'Gold Accent Bracelet', 'Bracelet with subtle gold accents.', 6000.00, 'bracelet6.jpg', 28, 'bracelets', 'bracelet6_2.jpg', 'bracelet6_3.jpg', 1),
(37, 'Braided Leather Bracelet', 'Braided leather bracelet with refined design.', 3000.00, 'bracelet7.jpg', 36, 'bracelets', 'bracelet7_2.jpg', 'bracelet7_3.jpg', 1),
(38, 'Magnetic Clasp Bracelet', 'Secure bracelet with magnetic clasp.', 3500.00, 'bracelet8.jpg', 34, 'bracelets', 'bracelet8_2.jpg', 'bracelet8_3.jpg', 1),
(39, 'Minimal Black Bracelet', 'Simple black bracelet for daily wear.', 6500.00, 'bracelet9.jpg', 45, 'bracelets', 'bracelet9_2.jpg', 'bracelet9_3.jpg', 1),
(40, 'Luxury Stone Bracelet', 'Luxury stone bracelet with polished beads.', 1000.00, 'bracelet10.jpg', 26, 'bracelets', 'bracelet10_2.jpg', 'bracelet10_3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `created_at`, `admin_reply`) VALUES
(9, 39, 3, 5, 'amazing product', '2025-12-29 11:46:39', 'thankyou for the feedback!');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `status` enum('active','banned') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `phone`, `address`, `city`, `role`, `status`) VALUES
(2, 'Admin', 'admin@timenest.com', 'admin123', '2025-12-25 20:52:30', NULL, NULL, NULL, 'admin', 'active'),
(3, 'eman raza', 'eman.raza@timenest.com', 'dash123', '2025-12-28 19:07:24', NULL, NULL, NULL, 'user', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
