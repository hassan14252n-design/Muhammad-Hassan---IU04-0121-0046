<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id=? AND is_active=1 ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History – TimeNest</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .checkout-container { max-width: 900px; margin: 60px auto; grid-template-columns:1fr; }
        .checkout-box { background:#1a1a1a; padding:25px; border-radius:14px; box-shadow:0 10px 30px rgba(0,0,0,0.4); }
        h2 { color:#c2b280; margin-bottom:20px; }

        table { width:100%; border-collapse: collapse; color:#f5f5dc; }
        th, td { padding:12px; text-align:left; border-bottom:1px solid #333; }
        th { color:#c2b280; }

        .view-btn { background:#c2b280; color:#121212; padding:8px 12px; border:none; border-radius:6px; cursor:pointer; }
        .view-btn:hover { box-shadow:0 4px 12px rgba(194,178,128,0.4); }

        /* Modal */
        .modal { display:none; position:fixed; inset:0; background: rgba(0,0,0,0.75); justify-content:center; align-items:center; z-index:1000; }
        .modal-content { background:#1a1a1a; padding:25px; border-radius:12px; max-width:600px; width:90%; position:relative; }
        .modal-close { position:absolute; top:12px; right:12px; cursor:pointer; font-size:20px; color:#c2b280; }
        .order-item { display:flex; justify-content:space-between; margin-bottom:12px; }
        .order-item img { width:60px; height:60px; object-fit:cover; border-radius:8px; margin-right:12px; }
        .order-item-details { flex:1; }
        .order-item-name { color:#f5f5dc; }
        .order-item-qty-price { color:#ddd; font-size:14px; }
        .order-total { display:flex; justify-content:space-between; font-weight:bold; margin-top:20px; color:#c2b280; }
    </style>
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="checkout-container">
    <div class="checkout-box">
        <h2>Order History</h2>
        <?php if($orders->num_rows === 0): ?>
            <p>No orders found.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Placed At</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($order = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= $order['created_at'] ?></td>
                        <td><?= $order['status'] ?? 'Pending' ?></td>
                        <td>Rs <?= number_format($order['total'],2) ?></td>
                        <td><button class="view-btn" data-order-id="<?= $order['id'] ?>">View</button></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div class="modal" id="orderModal">
    <div class="modal-content">
        <span class="modal-close" id="modalClose">&times;</span>
        <h2>Order Summary</h2>
        <div id="modalBody"></div>
    </div>
</div>

<script>
const modal = document.getElementById('orderModal');
const modalBody = document.getElementById('modalBody');
const modalClose = document.getElementById('modalClose');

document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const orderId = btn.dataset.orderId;

        fetch('fetch_order_items.php?id=' + orderId)
            .then(res => res.text())
            .then(data => {
                modalBody.innerHTML = data;
                modal.style.display = 'flex';
            });
    });
});

modalClose.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', e => {
    if(e.target === modal) modal.style.display = 'none';
});
</script>

</body>
</html>
