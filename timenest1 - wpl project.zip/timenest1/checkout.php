<?php
session_start();
include 'includes/db.php';

/* =====================
   AUTH CHECK
===================== */
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: cart.php");
    exit();
}

/* =====================
   HANDLE FORM SUBMISSION
===================== */
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $address   = trim($_POST['address'] ?? '');
    $city      = trim($_POST['city'] ?? '');
    $payment   = trim($_POST['payment_method'] ?? '');

    // Card fields
    $card_number = trim($_POST['card_number'] ?? '');
    $card_expiry = trim($_POST['card_expiry'] ?? '');
    $card_cvv    = trim($_POST['card_cvv'] ?? '');

    // Validation
    if ($full_name === '') $errors[] = "Full name is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email address.";
    if (!preg_match('/^\+?\d{10,15}$/', $phone)) $errors[] = "Please enter a valid phone number.";
    if ($address === '') $errors[] = "Address is required.";
    if ($city === '') $errors[] = "City is required.";
    if ($payment === '') $errors[] = "Please select a payment method.";

    // Card validation only if credit card selected
    if ($payment === 'Credit Card') {
        if (!preg_match('/^\d{16}$/', $card_number)) {
            $errors[] = "Card number must be 16 digits.";
        }
        if (!preg_match('/^\d{2}\/\d{2}$/', $card_expiry)) {
            $errors[] = "Expiry must be in MM/YY format.";
        }
        if (!preg_match('/^\d{3}$/', $card_cvv)) {
            $errors[] = "CVV must be 3 digits.";
        }
    }

    if (empty($errors)) {
        $_SESSION['checkout_data'] = [
            'full_name' => $full_name,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'payment_method' => $payment
        ];

        header("Location: place_order.php");
        exit();
    }
}

/* =====================
   CALCULATE TOTAL
===================== */
$total = 0;
foreach ($cart as $item) {
    $total += (float)$item['price'] * (int)$item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout – TimeNest</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="checkout-container">

    <!-- LEFT -->
    <div class="checkout-box">
        <h2>Billing & Payment</h2>

        <?php if (!empty($errors)): ?>
            <div class="error-box show">
                <strong>⚠ Please fix the following:</strong>
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" novalidate>

            <input type="text" name="full_name" placeholder="Full Name"
                   value="<?= htmlspecialchars($_POST['full_name'] ?? $user['name'] ?? '') ?>">

            <input type="text" name="email" placeholder="Email"
                   value="<?= htmlspecialchars($_POST['email'] ?? $user['email'] ?? '') ?>">

            <input type="text" name="phone" placeholder="Phone Number"
                   value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

            <input type="text" name="address" placeholder="Address"
                   value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">

            <!-- CITY DROPDOWN -->
            <select name="city">
                <option value="">Select City</option>
                <?php
                $cities = [
                    "Karachi","Lahore","Islamabad","Rawalpindi","Faisalabad",
                    "Multan","Peshawar","Quetta","Sialkot","Gujranwala","Hyderabad"
                ];
                foreach ($cities as $c):
                ?>
                    <option value="<?= $c ?>" <?= (($_POST['city'] ?? '') === $c) ? 'selected' : '' ?>>
                        <?= $c ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- PAYMENT METHOD -->
            <select name="payment_method" id="paymentMethod">
                <option value="">Select Payment Method</option>
                <option value="Cash on Delivery" <?= (($_POST['payment_method'] ?? '')==='Cash on Delivery')?'selected':'' ?>>
                    Cash on Delivery
                </option>
                <option value="Credit Card" <?= (($_POST['payment_method'] ?? '')==='Credit Card')?'selected':'' ?>>
                    Credit Card
                </option>
            </select>

            <!-- CREDIT CARD FIELDS -->
            <div id="cardFields" style="display:none;">
                <input type="text" name="card_number" placeholder="Card Number (16 digits)"
                       value="<?= htmlspecialchars($_POST['card_number'] ?? '') ?>">
                <input type="text" name="card_expiry" placeholder="MM/YY"
                       value="<?= htmlspecialchars($_POST['card_expiry'] ?? '') ?>">
                <input type="text" name="card_cvv" placeholder="CVV"
                       value="<?= htmlspecialchars($_POST['card_cvv'] ?? '') ?>">
            </div>

            <button type="submit" class="checkout-btn">Place Order</button>
        </form>
    </div>

    <!-- RIGHT -->
    <div class="checkout-summary">
        <h2>Order Summary</h2>

        <?php foreach ($cart as $item):
            $subtotal = (float)$item['price'] * (int)$item['quantity'];
        ?>
            <div class="checkout-item">
                <span><?= htmlspecialchars($item['name']) ?> × <?= (int)$item['quantity'] ?></span>
                <span>Rs <?= number_format($subtotal, 2) ?></span>
            </div>
        <?php endforeach; ?>

        <div class="checkout-total">
            <span>Total</span>
            <span>Rs <?= number_format($total, 2) ?></span>
        </div>

        <a href="cart.php" class="edit-order-btn">Edit Cart</a>
    </div>

</div>

<script>
const paymentMethod = document.getElementById('paymentMethod');
const cardFields = document.getElementById('cardFields');

function toggleCardFields() {
    cardFields.style.display = paymentMethod.value === 'Credit Card' ? 'block' : 'none';
}
paymentMethod.addEventListener('change', toggleCardFields);
toggleCardFields();
</script>

</body>
</html>
