<?php
include '../includes/db.php';
include '../includes/auth.php';

if(!isset($_GET['id'])) exit;

$id = intval($_GET['id']);
$conn->query("UPDATE products SET is_active = 0 WHERE id=$id");

header("Location: products.php");
exit;
