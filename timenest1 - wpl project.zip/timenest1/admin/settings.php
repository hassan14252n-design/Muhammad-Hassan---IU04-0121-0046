<?php
include '../includes/auth.php'; // Ensure admin is logged in
include '../includes/db.php';
include '../includes/admin_header.php';
include '../includes/admin_navbar.php';

$adminId = $_SESSION['user']['id'];
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = trim($_POST['password']);

    if (empty($name) || empty($email)) {
        $error = "Name and email cannot be empty.";
    } else {
        if (!empty($password)) {
            // You can hash the password here if desired
            $password = $conn->real_escape_string($password);
            $sql = "UPDATE users SET name='$name', email='$email', password='$password' WHERE id=$adminId";
        } else {
            $sql = "UPDATE users SET name='$name', email='$email' WHERE id=$adminId";
        }

        if ($conn->query($sql)) {
            $_SESSION['user']['name'] = $name;
            $_SESSION['user']['email'] = $email;
            $success = "Settings updated successfully.";
        } else {
            $error = "Error updating settings.";
        }
    }
}

// Fetch current admin info
$result = $conn->query("SELECT name, email FROM users WHERE id=$adminId")->fetch_assoc();
?>

<div class="admin-main">
    <h1>Admin Settings</h1>

    <?php if ($error): ?>
        <div class="modal-overlay show">
            <div class="modal">
                <p><?= htmlspecialchars($error) ?></p>
                <button onclick="this.parentElement.parentElement.classList.remove('show')">Close</button>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="modal-overlay show">
            <div class="modal">
                <p><?= htmlspecialchars($success) ?></p>
                <button onclick="this.parentElement.parentElement.classList.remove('show')">Close</button>
            </div>
        </div>
    <?php endif; ?>

    <form class="admin-form" method="POST">
        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($result['name']) ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($result['email']) ?>" required>

        <label>Password (leave blank to keep current)</label>
        <input type="password" name="password">

        <button type="submit">Update Settings</button>
    </form>
</div>
