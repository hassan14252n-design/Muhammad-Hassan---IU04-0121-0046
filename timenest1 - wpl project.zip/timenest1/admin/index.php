<?php
include '../includes/auth.php';
include '../includes/db.php';
include '../includes/admin_header.php';
include '../includes/admin_navbar.php';

// Fetch counts
$userCount    = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$productCount = $conn->query("SELECT COUNT(*) as total FROM products")->fetch_assoc()['total'];
$orderCount   = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];
$reviewCount = $conn->query("SELECT COUNT(*) as total FROM reviews")->fetch_assoc()['total'];

?>

<div class="admin-header">
    <h1>Dashboard</h1>
</div>

<div class="admin-main">
    <div class="dashboard-cards">
        <div class="dashboard-card">
            <h3>Users</h3>
            <p><?= $userCount ?></p>
            <a href="users.php" class="edit-btn">Manage Users</a>
        </div>

        <div class="dashboard-card">
            <h3>Products</h3>
            <p><?= $productCount ?></p>
            <a href="products.php" class="edit-btn">Manage Products</a>
        </div>

        <div class="dashboard-card">
            <h3>Orders</h3>
            <p><?= $orderCount ?></p>
            <a href="orders.php" class="edit-btn">Manage Orders</a>
        </div>
        <div class="dashboard-card">
            <h3>Reviews</h3>
            <p><?= $reviewCount ?></p>
            <a href="reviews.php" class="edit-btn">Manage Reviews</a>
        </div>
    </div>
</div>

<?php include '../includes/admin_footer.php'; ?>
