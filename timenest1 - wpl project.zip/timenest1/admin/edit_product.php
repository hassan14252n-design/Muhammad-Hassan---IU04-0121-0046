<?php
include '../includes/auth.php';
include '../includes/db.php';

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit;
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: products.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);

    $image = $product['image'];

    if (!empty($_FILES['image']['name'])) {
        $image = time() . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }

    $update = $conn->prepare("
        UPDATE products 
        SET name = ?, price = ?, description = ?, image = ?
        WHERE id = ?
    ");
    $update->bind_param("ssssi", $name, $price, $description, $image, $id);
    $update->execute();

    header("Location: products.php");
    exit;
}

include '../includes/admin_header.php';
include '../includes/admin_navbar.php';
?>

<div class="admin-form-container">
    <h2>Edit Product</h2>

    <form method="POST" enctype="multipart/form-data">

        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>

        <label>Price</label>
        <input type="text" name="price" value="<?= htmlspecialchars($product['price']) ?>" required>

        <label>Description</label>
        <textarea name="description"><?= htmlspecialchars($product['description']) ?></textarea>

        <label>Image</label>
        <input type="file" name="image">

        <?php if ($product['image']): ?>
            <img src="../uploads/<?= $product['image'] ?>" class="preview-img">
        <?php endif; ?>

        <div class="form-actions">
            <button type="submit" class="save-btn">Save Changes</button>
            <a href="products.php" class="cancel-btn">Cancel</a>
        </div>

    </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
