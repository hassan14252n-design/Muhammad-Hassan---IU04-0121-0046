<?php
include '../includes/auth.php';
include '../includes/db.php';

$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
include '../includes/admin_header.php';
include '../includes/admin_navbar.php';
?>

<div class="admin-main">
    <h2>All Products</h2>
    <a href="add_product.php" class="edit-btn" style="margin-bottom:15px; display:inline-block;">
        + Add Product</a>
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price (PKR)</th>
                <th>Image</th>
               <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($product = $products->fetch_assoc()): ?>
            <tr>
                <td><?= $product['id'] ?></td>
                <td><?= htmlspecialchars($product['name']) ?></td>
                <td><?= $product['price'] ?></td>
                <td>
                    <?php if($product['image']): ?>
                    <img src="../uploads/<?= $product['image'] ?>" width="60">
                    <?php endif; ?>
                </td>
                <td><?= $product['is_active'] ? 'Active' : 'Deleted' ?></td>

                <td>
                    <a href="edit_product.php?id=<?= $product['id'] ?>" class="edit-btn">Edit</a>
                    <a href="delete_product.php?id=<?= $product['id'] ?>" class="delete-btn" onclick="return confirm('Delete this product?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
