<?php
include '../includes/auth.php';
include '../includes/db.php';

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: orders.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $total  = trim($_POST['total']);

    $update = $conn->prepare("UPDATE orders SET status = ?, total = ? WHERE id = ?");
    $update->bind_param("ssi", $status, $total, $id);
    $update->execute();

    header("Location: orders.php");
    exit;
}

include '../includes/admin_header.php';
include '../includes/admin_navbar.php';
?>

<div class="admin-form-container">
    <h2>Edit Order #<?= $order['id']; ?></h2>

    <form method="POST">

        <label>Status</label>
        <select name="status">
            <option value="Pending"   <?= $order['status'] === 'Pending'   ? 'selected' : '' ?>>Pending</option>
            <option value="Completed" <?= $order['status'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
            <option value="Canceled"  <?= $order['status'] === 'Canceled'  ? 'selected' : '' ?>>Canceled</option>
        </select>

        <label>Total Price (PKR)</label>
        <input type="text" name="total" value="<?= htmlspecialchars($order['total']); ?>" required>

        <div class="form-actions">
            <button type="submit" class="save-btn">Save Changes</button>
            <a href="orders.php" class="cancel-btn">Cancel</a>
        </div>
    </form>
</div>

<?php include '../includes/admin_footer.php'; ?>
