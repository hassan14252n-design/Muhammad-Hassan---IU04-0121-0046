<?php
include '../includes/db.php';
include '../includes/auth.php'; // ensures admin

if(!isset($_GET['id'])) exit;

$id = intval($_GET['id']);
$conn->query("DELETE FROM users WHERE id=$id");
header("Location: users.php");
exit;
