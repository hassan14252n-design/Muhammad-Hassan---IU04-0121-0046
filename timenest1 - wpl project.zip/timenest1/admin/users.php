<?php
include '../includes/auth.php';
include '../includes/db.php';

$users = $conn->query("SELECT * FROM users ORDER BY id DESC");

include '../includes/admin_header.php';
include '../includes/admin_navbar.php';
?>

<div class="admin-main">
    <h2>Users</h2>

    <table class="admin-table">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php while ($user = $users->fetch_assoc()): ?>
        <tr>
            <td><?= $user['id'] ?></td>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= ucfirst($user['role']) ?></td>

            <td>
                <?= ($user['status'] === 'banned')
                    ? '<span style="color:red;">Banned</span>'
                    : '<span style="color:lightgreen;">Active</span>' ?>
            </td>

            <td>
                <!-- View -->
                <button class="edit-btn" onclick="openUserModal(<?= $user['id'] ?>)">
                    View
                </button>

                <!-- Ban (only if not admin) -->
                <?php if ($user['role'] !== 'admin'): ?>
                    <?php if ($user['status'] === 'active'): ?>
                        <a href="ban_user.php?id=<?= $user['id'] ?>"
                           class="ban-btn"
                           onclick="return confirm('Ban this user?')">
                           Ban
                        </a>
                    <?php else: ?>
                        <span style="color:#aaa;">Banned</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span style="color:#777;">Admin</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<!-- USER MODAL -->
<div class="modal-overlay" id="userModal">
    <div class="modal">
        <div id="modalContent"></div>
    </div>
</div>

<script>
function openUserModal(id) {
    fetch('view_user.php?id=' + id)
        .then(res => res.text())
        .then(data => {
            document.getElementById('modalContent').innerHTML = data;
            document.getElementById('userModal').classList.add('show');
        });
}

function closeModal() {
    document.getElementById('userModal').classList.remove('show');
}
</script>

<?php include '../includes/admin_footer.php'; ?>
