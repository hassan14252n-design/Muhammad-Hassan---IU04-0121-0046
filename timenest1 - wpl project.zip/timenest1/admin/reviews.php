<?php
include '../includes/auth.php';
include '../includes/db.php';
include '../includes/admin_header.php';
include '../includes/admin_navbar.php';

/* Save reply */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $reply = $_POST['reply'];

    $stmt = $conn->prepare("UPDATE reviews SET admin_reply=? WHERE id=?");
    $stmt->bind_param("si", $reply, $id);
    $stmt->execute();
}

/* Fetch reviews */
$reviews = $conn->query("
    SELECT r.*, u.name AS user_name, p.name AS product_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN products p ON r.product_id = p.id
    ORDER BY r.id DESC
");
?>

<div class="admin-main">
    <h1>Customer Reviews</h1>

    <table class="admin-table">
        <tr>
            <th>User</th>
            <th>Product</th>
            <th>Rating</th>
            <th>Review</th>
            <th>Reply</th>
        </tr>

        <?php while ($r = $reviews->fetch_assoc()): ?>
        <tr>
            <td><?= $r['user_name'] ?></td>
            <td><?= $r['product_name'] ?></td>
            <td><?= $r['rating'] ?>/5</td>
            <td><?= $r['comment'] ?></td>

            <td>
                <form method="POST">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="text"
                           name="reply"
                           value="<?= $r['admin_reply'] ?>"
                           placeholder="Write reply..."
                           style="width:100%; padding:6px;">
                    <button class="edit-btn" style="margin-top:5px;">
                        Save
                    </button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
