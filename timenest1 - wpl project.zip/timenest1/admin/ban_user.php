<?php
include '../includes/auth.php';
include '../includes/db.php';

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit;
}

$id = intval($_GET['id']);

/* Prevent banning admin */
$check = $conn->prepare("SELECT role FROM users WHERE id = ?");
$check->bind_param("i", $id);
$check->execute();
$result = $check->get_result()->fetch_assoc();

if (!$result || $result['role'] === 'admin') {
    header("Location: users.php");
    exit;
}

/* Ban user (soft delete) */
$stmt = $conn->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: users.php");
exit;
