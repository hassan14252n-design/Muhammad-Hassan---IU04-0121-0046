<?php
include '../includes/auth.php';
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $_POST['name'];
    $price    = $_POST['price'];
    $desc     = $_POST['description'];
    $quantity = $_POST['quantity'] ?? 0;
    $category = $_POST['category'] ?? '';
    
    // Images
    $images = [];
    for ($i = 1; $i <= 3; $i++) {
        if (!empty($_FILES["image$i"]['name'])) {
            $imgName = time().'_'.$_FILES["image$i"]['name'];
            move_uploaded_file($_FILES["image$i"]['tmp_name'], '../uploads/'.$imgName);
            $images[$i] = $imgName;
        } else {
            $images[$i] = '';
        }
    }

    $conn->query("INSERT INTO products 
        (name, description, price, quantity, category, image, image2, image3, is_active) 
        VALUES 
        ('$name', '$desc', '$price', '$quantity', '$category', '{$images[1]}', '{$images[2]}', '{$images[3]}', 1)
    ");

    header("Location: products.php");
    exit;
}
?>

<?php include '../includes/admin_header.php'; ?>
<?php include '../includes/admin_navbar.php'; ?>

<div class="admin-main">
    <h1>Add Product</h1>
    <div class="admin-form-container">
        <form method="POST" enctype="multipart/form-data" class="admin-form">
            <label>Name</label>
            <input type="text" name="name" required>

            <label>Price (PKR)</label>
            <input type="number" name="price" step="0.01" required>

            <label>Description</label>
            <textarea name="description" required></textarea>

            <label>Quantity</label>
            <input type="number" name="quantity" value="0" required>

            <label>Category</label>
            <input type="text" name="category">

            <label>Image 1</label>
            <input type="file" name="image1" class="preview-img">

            <label>Image 2</label>
            <input type="file" name="image2" class="preview-img">

            <label>Image 3</label>
            <input type="file" name="image3" class="preview-img">

            <div class="form-actions">
                <button type="submit" class="save-btn">Add Product</button>
                <a href="products.php" class="cancel-btn">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/admin_footer.php'; ?>
