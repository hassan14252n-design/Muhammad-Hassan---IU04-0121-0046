<?php
include '../includes/auth.php';
include '../includes/db.php';

$orders = $conn->query("SELECT *, IF(is_active=1,'Active','Deleted') AS display_status FROM orders ORDER BY id DESC");
include '../includes/admin_header.php';
include '../includes/admin_navbar.php';
?>

<div class="admin-main">
    <h2>All Orders</h2>
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Total Price (PKR)</th>
                <th>Status</th>
                <th>Activity</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($order = $orders->fetch_assoc()): ?>
            <tr>
                <td><?= $order['id'] ?></td>
                <td><?= $order['user_id'] ?></td>
                <td><?= $order['total'] ?></td>
                <td><?= $order['status'] ?></td>
                <td><?= $order['display_status'] ?></td>

                <td>
                    <a href="edit_order.php?id=<?= $order['id'] ?>" class="edit-btn">Edit</a>
                    <a href="delete_order.php?id=<?= $order['id'] ?>" class="delete-btn" onclick="return confirm('Delete this order?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>
