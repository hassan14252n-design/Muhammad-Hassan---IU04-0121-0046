<?php
include '../includes/auth.php';
include '../includes/db.php';

if (!isset($_GET['id'])) {
    exit("Invalid user.");
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT name, email, phone, city, role, status FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    exit("User not found.");
}
?>

<h3>User Details</h3>

<p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
<p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
<p><strong>Phone:</strong> <?= htmlspecialchars($user['phone'] ?? 'N/A') ?></p>
<p><strong>City:</strong> <?= htmlspecialchars($user['city'] ?? 'N/A') ?></p>
<p><strong>Role:</strong> <?= ucfirst($user['role']) ?></p>
<p><strong>Status:</strong> <?= ucfirst($user['status'] ?? 'active') ?></p>

<br>

<button onclick="closeModal()" class="edit-btn">Close</button>
