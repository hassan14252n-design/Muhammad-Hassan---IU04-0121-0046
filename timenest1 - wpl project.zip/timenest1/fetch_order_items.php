<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo "Unauthorized";
    exit();
}

$order_id = $_GET['id'] ?? null;
if (!$order_id) {
    http_response_code(400);
    echo "Invalid order ID";
    exit();
}

/* =====================
   FETCH ORDER ITEMS
===================== */
$stmt = $conn->prepare(
    "SELECT oi.quantity, oi.price, p.name, p.image 
     FROM order_items oi 
     JOIN products p ON oi.product_id = p.id 
     WHERE oi.order_id = ?"
);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items = $stmt->get_result();
$stmt->close();

/* =====================
   FETCH ORDER TOTAL
===================== */
$totalStmt = $conn->prepare("SELECT total FROM orders WHERE id=? AND user_id=?");
$totalStmt->bind_param("ii", $order_id, $_SESSION['user']['id']);
$totalStmt->execute();
$order_total = $totalStmt->get_result()->fetch_assoc()['total'];
$totalStmt->close();

if ($order_items->num_rows === 0) {
    echo "<p>No items found for this order.</p>";
    exit();
}

/* =====================
   OUTPUT HTML
===================== */
$total = 0;
foreach ($order_items as $item) {
    $subtotal = $item['price'] * $item['quantity'];
    $total += $subtotal;
    echo '<div class="order-item">';
    echo '<img src="uploads/' . htmlspecialchars($item['image']) . '" alt="' . htmlspecialchars($item['name']) . '">';
    echo '<div class="order-item-details">';
    echo '<div class="order-item-name">' . htmlspecialchars($item['name']) . '</div>';
    echo '<div class="order-item-qty-price">' . $item['quantity'] . ' × Rs ' . number_format($item['price'],2) . '</div>';
    echo '</div>';
    echo '<div class="order-item-subtotal">Rs ' . number_format($subtotal,2) . '</div>';
    echo '</div>';
}

echo '<div class="order-total"><span>Total:</span><span>Rs' . number_format($order_total,2) . '</span></div>';
