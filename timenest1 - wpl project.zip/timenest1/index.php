<?php 
session_start();
include 'includes/db.php';

// Cart count
$cartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) $cartCount += $item['quantity'];
}

// Filters
$search   = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$sort     = $_GET['sort'] ?? '';

// Sorting
$sortSql = match($sort) {
    'price_asc'  => " ORDER BY price ASC",
    'price_desc' => " ORDER BY price DESC",
    'name_asc'   => " ORDER BY name ASC",
    'name_desc'  => " ORDER BY name DESC",
    default      => " ORDER BY id DESC"
};

// Fetch all products
$sql = "SELECT * FROM products WHERE is_active=1";
$params = []; $types = "";

if ($search) { $sql .= " AND name LIKE ?"; $params[] = "%$search%"; $types .= "s"; }
if ($category && $category !== 'all') { $sql .= " AND category=?"; $params[] = $category; $types .= "s"; }
$sql .= $sortSql;

$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$allProducts = $stmt->get_result();

// Featured products (latest per category)
$featuredProducts = [];
foreach (['bags','wallets','bracelets','watches'] as $cat) {
    $stmtF = $conn->prepare("SELECT * FROM products WHERE category=? AND is_active=1 ORDER BY id DESC LIMIT 1");
    $stmtF->bind_param("s", $cat);
    $stmtF->execute();
    if ($res = $stmtF->get_result()->fetch_assoc()) $featuredProducts[] = $res;
    $stmtF->close();
}

$isHomePage = empty($category) || $category==='';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TimeNest</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<?php if ($isHomePage): ?>
<div class="hero">
    <div class="hero-content">
        <h1>Discover Timeless Elegance</h1>
        <p>Premium accessories curated for modern style.</p>
    </div>
</div>

<h2 class="section-title">Featured Products</h2>
<div class="products">
<?php foreach ($featuredProducts as $row): ?>
    <div class="product">
        <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
        <div class="product-overlay">
            <a href="product.php?id=<?= $row['id'] ?>">View Details</a>
        </div>
        <h4><?= htmlspecialchars($row['name']) ?></h4>
        <p>Rs <?= htmlspecialchars($row['price']) ?></p>
        <form action="add_to_cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
            <button type="submit">Add to Cart</button>
        </form>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Filters -->
<div class="filters">
    <form method="GET" style="display:flex; gap:10px;">
        <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
        <?php if($category) echo '<input type="hidden" name="category" value="'.htmlspecialchars($category).'">' ?>
        <button type="submit">Search</button>
    </form>

    <form method="GET">
        <?php if($search) echo '<input type="hidden" name="search" value="'.htmlspecialchars($search).'">' ?>
        <?php if($category) echo '<input type="hidden" name="category" value="'.htmlspecialchars($category).'">' ?>
        <select name="sort" onchange="this.form.submit()">
            <option value="">Sort By</option>
            <option value="price_asc"  <?= $sort==='price_asc' ? 'selected' : '' ?>>Price Low → High</option>
            <option value="price_desc" <?= $sort==='price_desc'? 'selected' : '' ?>>Price High → Low</option>
            <option value="name_asc"   <?= $sort==='name_asc' ? 'selected' : '' ?>>Name A → Z</option>
            <option value="name_desc"  <?= $sort==='name_desc'? 'selected' : '' ?>>Name Z → A</option>
        </select>
    </form>
</div>

<h2 class="section-title">
    <?= $isHomePage ? 'Browse All Products' : ucfirst($category).' Products' ?>
</h2>

<div class="products">
<?php if ($allProducts->num_rows === 0): ?>
    <p style="text-align:center; color:#aaa;">No products found.</p>
<?php endif; ?>

<?php while ($row = $allProducts->fetch_assoc()): ?>
    <div class="product">
        <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
        <div class="product-overlay">
            <a href="product.php?id=<?= $row['id'] ?>">View Details</a>
        </div>
        <h4><?= htmlspecialchars($row['name']) ?></h4>
        <p>Rs <?= htmlspecialchars($row['price']) ?></p>
        <form action="add_to_cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
            <button type="submit">Add to Cart</button>
        </form>
    </div>
<?php endwhile; ?>
</div>

<footer>
    &copy; <?= date('Y') ?> TimeNest
</footer>

<script>
const searchInput = document.querySelector('input[name="search"]');
const productsContainer = document.querySelector('.products');

searchInput.addEventListener('input', function() {
    const query = this.value;
    const category = "<?= htmlspecialchars($category) ?>";
    const sort = "<?= htmlspecialchars($sort) ?>";

    fetch(`search_ajax.php?q=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}&sort=${encodeURIComponent(sort)}`)
        .then(res => res.text())
        .then(html => { productsContainer.innerHTML = html; });
});
</script>

</body>
</html>
