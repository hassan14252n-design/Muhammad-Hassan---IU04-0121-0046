<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

/* =====================
   HANDLE FORM SUBMISSION
===================== */
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $address = trim($_POST['address'] ?? '');

    // Validation
    if ($name === '') $errors[] = "Name is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email.";
    if ($address === '') $errors[] = "Address is required.";

    if (empty($errors)) {
        if ($password !== '') {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET name=?, email=?, password=?, address=? WHERE id=?");
            $stmt->bind_param("ssssi", $name, $email, $hashedPassword, $address, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?, email=?, address=? WHERE id=?");
            $stmt->bind_param("sssi", $name, $email, $address, $user_id);
        }
        if ($stmt->execute()) {
            $_SESSION['user']['name'] = $name;
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['address'] = $address;
            $success = "Profile updated successfully!";
        } else {
            $errors[] = "Error updating profile.";
        }
        $stmt->close();
    }
}

$stmt = $conn->prepare("SELECT name, email, address FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile – TimeNest</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="checkout-container" style="max-width:600px; margin:60px auto; grid-template-columns:1fr;">
    <div class="checkout-box">
        <h2>User Profile</h2>

        <?php if (!empty($errors)): ?>
            <div class="error-list">
                <?php foreach ($errors as $err): ?>
                    <div><?= htmlspecialchars($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div style="background:#2a2a2a; color:#c2b280; padding:10px; border-radius:8px; margin-bottom:15px;">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label>Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

            <label>Password <small>(leave blank to keep current)</small></label>
            <input type="password" name="password" placeholder="New Password">

            <label>Address</label>
            <input type="text" name="address" value="<?= htmlspecialchars($user['address']) ?>" required>

            <button type="submit" class="checkout-btn">Update Profile</button>
        </form>
    </div>
</div>
<!-- POPUP -->
<div id="profilePopup" class="popup-overlay">
    <div class="popup">
        <div class="popup-icon">✓</div>
        <h3>Profile Updated</h3>
        <p>Your changes were saved.</p>
    </div>
</div>

<?php if ($success): ?>
<script>
    const popup = document.getElementById('profilePopup');
    popup.classList.add('show');

    setTimeout(() => {
        popup.classList.remove('show');
    }, 1800);
</script>
<?php endif; ?>

</body>
</html>
