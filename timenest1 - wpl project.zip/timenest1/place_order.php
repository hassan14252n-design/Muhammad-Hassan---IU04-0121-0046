<?php
session_start();
include 'includes/db.php';

/* =====================
   AUTH CHECK
===================== */
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: cart.php");
    exit();
}

/* =====================
   GET VALIDATED CHECKOUT DATA
===================== */
$checkout = $_SESSION['checkout_data'] ?? null;
if (!$checkout) {
    // No validated checkout data
    header("Location: checkout.php");
    exit();
}

$user_id   = $_SESSION['user']['id'];
$full_name = $checkout['full_name'];
$email     = $checkout['email'];
$phone     = $checkout['phone'];
$address   = $checkout['address'];
$city      = $checkout['city'];
$payment   = $checkout['payment_method'];

/* =====================
   CALCULATE TOTAL
===================== */
$total = 0;
foreach ($cart as $item) {
    $total += (float)$item['price'] * (int)$item['quantity'];
}

/* =====================
   INSERT ORDER
===================== */
$orderStmt = $conn->prepare(
    "INSERT INTO orders 
    (user_id, total, full_name, email, phone, address, city, payment_method) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);

$orderStmt->bind_param(
    "idssssss",
    $user_id,
    $total,
    $full_name,
    $email,
    $phone,
    $address,
    $city,
    $payment
);

$orderStmt->execute();
$order_id = $orderStmt->insert_id;
$orderStmt->close();

/* =====================
   INSERT ORDER ITEMS
===================== */
$itemStmt = $conn->prepare(
    "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)"
);

foreach ($cart as $item) {
    $product_id = (int)$item['id'];
    $qty        = (int)$item['quantity'];
    $price      = (float)$item['price'];

    $itemStmt->bind_param("iiid", $order_id, $product_id, $qty, $price);
    $itemStmt->execute();
}
$itemStmt->close();

/* =====================
   CLEAR CART & CHECKOUT DATA
===================== */
unset($_SESSION['cart']);
unset($_SESSION['checkout_data']);

/* =====================
   REDIRECT TO SUCCESS
===================== */
header("Location: order_success.php?id=" . $order_id);
exit();
