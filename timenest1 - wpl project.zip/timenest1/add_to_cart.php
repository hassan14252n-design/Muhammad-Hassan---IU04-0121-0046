<?php
session_start();
include 'includes/db.php';

header('Content-Type: application/json');

if (!isset($_POST['product_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}

$product_id = (int) $_POST['product_id'];
$quantity = isset($_POST['quantity']) ? (int) $_POST['quantity'] : 1;

/* Fetch product */
$stmt = $conn->prepare("SELECT id, name, price, image FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    echo json_encode(['status' => 'error']);
    exit;
}

/* Initialize cart */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* Add or update */
if (isset($_SESSION['cart'][$product_id])) {
    $_SESSION['cart'][$product_id]['quantity'] += $quantity;
} else {
    $_SESSION['cart'][$product_id] = [
        'id'       => $product['id'],
        'name'     => $product['name'],
        'price'    => $product['price'],
        'image'    => $product['image'],
        'quantity' => $quantity
    ];
}

echo json_encode([
    'status' => 'success',
    'cartCount' => array_sum(array_column($_SESSION['cart'], 'quantity'))
]);
