<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$order_id = $_GET['id'] ?? null;
if (!$order_id) {
    die("Invalid order ID.");
}

/* =====================
   FETCH ORDER DETAILS
===================== */
$orderStmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$orderStmt->bind_param("ii", $order_id, $_SESSION['user']['id']);
$orderStmt->execute();
$order = $orderStmt->get_result()->fetch_assoc();
$orderStmt->close();

if (!$order) {
    die("Order not found.");
}

/* =====================
   FETCH ORDER ITEMS
===================== */
$itemStmt = $conn->prepare(
    "SELECT oi.quantity, oi.price, p.name, p.image 
     FROM order_items oi 
     JOIN products p ON oi.product_id = p.id 
     WHERE oi.order_id = ?"
);
$itemStmt->bind_param("i", $order_id);
$itemStmt->execute();
$order_items = $itemStmt->get_result();
$itemStmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Placed – TimeNest</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: #121212; color: #e0e0e0; font-family: Arial, sans-serif; }
        
        /* ===================== Confetti Overlay ===================== */
        .success-overlay {
            position: fixed;
            inset: 0;
            background: rgba(18,18,18,0.95);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            transition: opacity 0.5s ease;
        }
        .success-overlay.hidden { opacity: 0; pointer-events: none; }

        .success-overlay h1 {
            font-size: 48px;
            color: #c2b280;
            margin-bottom: 10px;
            animation: popIn 0.6s ease;
        }
        .success-overlay p {
            font-size: 18px;
            color: #f5f5dc;
        }

        @keyframes popIn {
            0% { transform: scale(0); opacity: 0; }
            70% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); }
        }

        .confetti-piece {
            position: absolute;
            top: -20px;
            opacity: 0.9;
            z-index: 10000;
            border-radius: 2px;
            animation-name: confettiFall;
            animation-timing-function: linear;
            animation-fill-mode: forwards;
        }

        @keyframes confettiFall {
            0% { transform: translateY(0) rotate(0deg); opacity: 1; }
            100% { transform: translateY(900px) rotate(720deg); opacity: 0; }
        }

        /* ===================== Order Details ===================== */
        #orderDetails {
            display: none;
            max-width: 1000px;
            margin: 60px auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            opacity: 0;
            animation: fadeIn 1s forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .customer-info, .order-summary {
            background: #1a1a1a;
            padding: 25px;
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        }

        .customer-info h2, .order-summary h2 { color: #c2b280; margin-bottom: 15px; }
        .order-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
        }
        .order-item img { width: 60px; height: 60px; object-fit: cover; border-radius: 8px; margin-right: 12px; }
        .order-item-details { flex: 1; }
        .order-item-name { color: #f5f5dc; }
        .order-item-qty-price { color: #ddd; font-size: 14px; }
        .order-item-subtotal { color: #c2b280; font-weight: bold; }
        .order-total { display: flex; justify-content: space-between; font-weight: bold; margin-top: 20px; color: #c2b280; }
        .success-btn {
            margin-top: 20px;
            width: 100%;
            background: #c2b280;
            color: #121212;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
            display: inline-block;
            text-decoration: none;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .success-btn:hover { box-shadow: 0 6px 18px rgba(194,178,128,0.4); transform: translateY(-2px); }
    </style>
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<!-- Full-screen Order Success Animation -->
<div class="success-overlay" id="successOverlay">
    <h1>✅ Order Successful!</h1>
    <p>Your order <strong>#<?= htmlspecialchars($order_id) ?></strong> has been placed</p>
    <?php 
    $colors = ['#c2b280','#ffcd3c','#e0e0e0','#f5f5dc'];
    for($i=0;$i<80;$i++): 
        $size = rand(6,12);
        $left = rand(0,100);
        $duration = rand(2500,4000)/1000;
        $rotate = rand(0,360);
        $color = $colors[array_rand($colors)];
    ?>
        <div class="confetti-piece" style="
            width: <?= $size ?>px;
            height: <?= $size ?>px;
            left: <?= $left ?>%;
            background-color: <?= $color ?>;
            animation-duration: <?= $duration ?>s;
            transform: rotate(<?= $rotate ?>deg);
        "></div>
    <?php endfor; ?>
</div>

<!-- Order Details -->
<div id="orderDetails">
    <!-- Customer Info -->
    <div class="customer-info">
        <h2>Customer Details</h2>
        <p><strong>Name:</strong> <?= htmlspecialchars($order['full_name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
        <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
        <p><strong>Address:</strong> <?= htmlspecialchars($order['address']) ?></p>
        <p><strong>Payment Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
    </div>

    <!-- Order Summary -->
    <div class="order-summary">
        <h2>Order Summary</h2>
        <?php 
        $total = 0;
        while ($item = $order_items->fetch_assoc()): 
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
        ?>
        <div class="order-item">
            <img src="uploads/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
            <div class="order-item-details">
                <div class="order-item-name"><?= htmlspecialchars($item['name']) ?></div>
                <div class="order-item-qty-price"><?= $item['quantity'] ?> × Rs <?= number_format($item['price'],2) ?></div>
            </div>
            <div class="order-item-subtotal">Rs <?= number_format($subtotal,2) ?></div>
        </div>
        <?php endwhile; ?>

        <div class="order-total">
            <span>Total:</span>
            <span>Rs <?= number_format($total,2) ?></span>
        </div>

        <a href="index.php" class="success-btn">🏠 Continue Shopping</a>
    </div>
</div>

<script>
// Hide animation and fade in details
setTimeout(() => {
    document.getElementById('successOverlay').classList.add('hidden');
    document.getElementById('orderDetails').style.display = 'grid';
}, 2500);
</script>

</body>
</html>
