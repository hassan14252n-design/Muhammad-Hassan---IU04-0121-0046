<?php include 'auth.php'; ?>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="index.php">Dashboard</a>
    <a href="users.php">Users</a>
    <a href="products.php">Products</a>
    <a href="orders.php">Orders</a>
     <a href="reviews.php">Reviews</a>
    <a href="settings.php">Settings</a>
    <a href="../logout.php">Logout</a>
</div>
