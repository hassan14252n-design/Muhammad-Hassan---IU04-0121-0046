<div class="admin-footer">
    &copy; <?= date('Y') ?> TimeNest - Admin Panel
</div>
</body>
</html>
