<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Cart Count */
$cartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}
?>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <h3>Categories</h3>
    <!-- Fixed "All" link -->
    <a href="index.php?category=all">All</a>
    <a href="index.php?category=bags">Bags</a>
    <a href="index.php?category=wallets">Wallets</a>
    <a href="index.php?category=bracelets">Bracelets</a>
    <a href="index.php?category=watches">Watches</a>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <!-- Left -->
    <div class="navbar-left">
        <button class="sidebar-toggle" id="sidebarToggle">☰</button>
    </div>

    <!-- Center -->
    <div class="navbar-center">
        <a href="index.php" class="company-name">TimeNest</a>
    </div>

    <!-- Right -->
    <div class="navbar-right">
        <a href="cart.php" class="cart-link">
            🛒 <span class="cart-count"><?= $cartCount ?></span>
        </a>

        <?php if (isset($_SESSION['user'])): ?>
            <div class="profile-container">
                <span class="profile-btn">👤 <?= htmlspecialchars($_SESSION['user']['name']) ?> ▾</span>
                <div class="profile-dropdown">
                    <a href="profile.php">User Info</a>
                    <a href="order_history.php">Order History</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="signup.php">Signup</a>
        <?php endif; ?>
    </div>
</div>

<script>
// Sidebar toggle
const sidebar = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');

sidebarToggle.addEventListener('click', () => {
    sidebar.style.left = sidebar.style.left === '0px' ? '-260px' : '0px';
});

// Close sidebar when clicking outside
document.addEventListener('click', function(event) {
    if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
        sidebar.style.left = '-260px';
    }
});
</script>
