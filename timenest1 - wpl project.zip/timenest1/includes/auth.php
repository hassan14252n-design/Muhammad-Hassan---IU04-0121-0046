<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
/* Not logged in */
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

/* Not admin */
if ($_SESSION['user']['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
