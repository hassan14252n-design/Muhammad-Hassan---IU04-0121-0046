<?php
session_start();
include("includes/db.php");

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND is_active = 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: index.php");
    exit;
}
$reviewStmt = $conn->prepare("
    SELECT reviews.*, users.name 
    FROM reviews 
    JOIN users ON reviews.user_id = users.id 
    WHERE product_id = ?
    ORDER BY created_at DESC
");
$reviewStmt->bind_param("i", $product['id']);
$reviewStmt->execute();
$reviews = $reviewStmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']); ?> | TimeNest</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="product-page">

    <!-- BACK BUTTON -->
    <a href="javascript:history.back()" class="back-btn">← Back to Products</a>

<div class="product-container">

<div class="product-image">
    <div class="gallery">
        <span class="arrow prev">&#10094;</span>
        <img src="uploads/<?= htmlspecialchars($product['image']); ?>" class="main-img" id="mainImage">
        <span class="arrow next">&#10095;</span>
    </div>
    <div class="thumbs">
        <img src="uploads/<?= htmlspecialchars($product['image']); ?>" class="thumb active">
        <img src="uploads/<?= htmlspecialchars($product['image2']); ?>" class="thumb">
        <img src="uploads/<?= htmlspecialchars($product['image3']); ?>" class="thumb">
    </div>
</div>



    <!-- DETAILS -->
    <div class="product-info">
        <h1><?= htmlspecialchars($product['name']); ?></h1>
        <p class="price">Rs <?= htmlspecialchars($product['price']); ?></p>

        <p class="description">
            <?= nl2br(htmlspecialchars($product['description'])); ?>
        </p>

        <form id="addToCartForm" class="cart-form">
            <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
            <label>Quantity</label>
            <input type="number" name="quantity" value="1" min="1">
            <button type="submit" class="add-btn">Add to Cart</button>
        </form>
    </div>
</div>

<!-- ✅ REVIEWS NOW SEPARATE -->
<div class="reviews-section">
    
    <h2>Customer Reviews</h2>

    <?php if (isset($_SESSION['user'])): ?>
        <form id="reviewForm" class="review-form">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <label>Rating</label>
            <select name="rating" required>
                <option value="">Select</option>
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="2">⭐⭐</option>
                <option value="1">⭐</option>
            </select>
            <textarea name="comment" placeholder="Write your review..." required></textarea> 
            <button type="submit">Submit Review</button> 
        </form> 
        <?php else: ?> 
            <p class="login-msg"> <a href="login.php">Login</a> to write a review. </p> 
            <?php endif; ?>
    <?php if ($reviews->num_rows > 0): ?>
       <?php while ($review = $reviews->fetch_assoc()): ?>
    <div class="review">
        <strong><?= htmlspecialchars($review['name']) ?></strong>
        <span class="stars"><?= str_repeat("⭐", (int)$review['rating']) ?></span>

        <p><?= nl2br(htmlspecialchars($review['comment'])) ?></p>

        <!-- ADMIN REPLY -->
        <?php if (!empty($review['admin_reply'])): ?>
            <div style="margin-top:8px; padding:8px; background:#1a1a1a; border-left:3px solid #c2b280;">
                <strong style="color:#c2b280;">Admin Reply:</strong><br>
                <?= nl2br(htmlspecialchars($review['admin_reply'])) ?>
            </div>
        <?php endif; ?>

        <small><?= date("F j, Y", strtotime($review['created_at'])) ?></small>
    </div>
<?php endwhile; ?>

    <?php else: ?>
        <p class="no-reviews">No reviews yet.</p>
    <?php endif; ?>

</div>
<footer>
    &copy; <?= date('Y'); ?> TimeNest
</footer>
<div id="popupOverlay" class="popup-overlay">
    <div class="popup">
        <div class="popup-icon">✓</div>
        <h3>Added to Cart</h3>
        <p>Your item has been added successfully.</p>
    </div>
</div>
<div id="reviewPopup" class="popup-overlay">
    <div class="popup">
        <div class="popup-icon">⭐</div>
        <h3>Review Submitted</h3>
        <p>Thanks for sharing your feedback!</p>
    </div>
</div>

<script>
const form = document.getElementById('addToCartForm');
const popup = document.getElementById('popupOverlay');

form.addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(form);

    fetch('add_to_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            showToast();
            updateCartCount(data.cartCount);
        }
    });
});

function showToast() {
    popup.classList.add('show');
    setTimeout(() => popup.classList.remove('show'), 1800);
}


function updateCartCount(count) {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        cartCount.textContent = count;
    }
}
const reviewForm = document.getElementById('reviewForm');
const reviewPopup = document.getElementById('reviewPopup');

if (reviewForm) {
    reviewForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(reviewForm);

        fetch('add_review.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showReviewPopup();
                reviewForm.reset();

                // OPTIONAL: reload reviews
                setTimeout(() => location.reload(), 1500);
            }
        });
    });
}

function showReviewPopup() {
    reviewPopup.classList.add('show');
    setTimeout(() => reviewPopup.classList.remove('show'), 1800);
}
</script>

<script>
const mainImg = document.getElementById('mainImg');
document.querySelectorAll('.thumb').forEach(thumb => {
    thumb.addEventListener('click', () => {
        mainImg.src = thumb.src;
    });
});
// ======== PRODUCT IMAGE GALLERY ========
const mainImage = document.getElementById('mainImage');
const thumbs = document.querySelectorAll('.product-image .thumbs img');
const prevArrow = document.querySelector('.product-image .arrow.prev');
const nextArrow = document.querySelector('.product-image .arrow.next');

let currentIndex = 0;

// Update main image when clicking a thumbnail
thumbs.forEach((thumb, index) => {
    thumb.addEventListener('click', () => {
        currentIndex = index;
        updateGallery();
    });
});

// Update main image when clicking arrows
prevArrow.addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + thumbs.length) % thumbs.length;
    updateGallery();
});

nextArrow.addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % thumbs.length;
    updateGallery();
});

function updateGallery() {
    mainImage.src = thumbs[currentIndex].src;

    thumbs.forEach((t, i) => {
        t.classList.toggle('active', i === currentIndex);
    });
}

</script>

</body>
</html>
