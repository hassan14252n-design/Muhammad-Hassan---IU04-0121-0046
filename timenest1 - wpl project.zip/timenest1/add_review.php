<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(['status' => 'error']);
    exit;
}

$user_id    = $_SESSION['user']['id'];
$product_id = (int)($_POST['product_id'] ?? 0);
$rating     = (int)($_POST['rating'] ?? 0);
$comment    = trim($_POST['comment'] ?? '');

if ($product_id === 0 || $rating < 1 || $rating > 5 || $comment === '') {
    echo json_encode(['status' => 'error']);
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO reviews (user_id, product_id, rating, comment, created_at)
    VALUES (?, ?, ?, ?, NOW())
");
$stmt->bind_param("iiis", $user_id, $product_id, $rating, $comment);
$stmt->execute();

echo json_encode(['status' => 'success']);
