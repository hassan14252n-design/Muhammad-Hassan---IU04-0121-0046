<?php
session_start();

$id = (int) $_POST['product_id'];

unset($_SESSION['cart'][$id]);

header("Location: cart.php");
exit;
